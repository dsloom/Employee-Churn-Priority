#here we use the cleaned dataframe

import pandas as pd
import pickle 
from sklearn.preprocessing import MinMaxScaler

from sklearn.neighbors import KNeighborsClassifier

import seaborn as sn
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression 
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score
import joblib
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn import preprocessing
from sklearn.decomposition import PCA
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV


from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn import preprocessing
import os

with open(os.path.join(os.getcwd(),"c_employee_df.pkl"),"rb") as c_employee_df:
    df= pickle.load(c_employee_df)
print(df)
encoder=LabelEncoder()
#data splitting
df["left_job"]=encoder.fit_transform(df["left_job"])
X= df.copy()
X.drop("left_job",axis=1,inplace=True)
y=df.pop("left_job")
print(X)
print(y)

# SCALING

scaler = preprocessing.MinMaxScaler(feature_range= (0, 1))
S_X = scaler.fit_transform(X)
S_X = pd.DataFrame(S_X, columns =["age","salary","tenure","performance_rating"])
S_X

# data splitting
X_train, X_test, y_train, y_test = train_test_split(S_X, y, test_size=0.2, random_state=42)

#EVALUATING THE SCORE

"""classifiers=[LogisticRegression(),DecisionTreeClassifier(),RandomForestClassifier(),KNeighborsClassifier()]
for classifier in classifiers:
  classifier.fit(X=X_train, y=y_train)
  y_pred_train = classifier.predict(X_train)
  print( f"{type(classifier).__name__} Train score = {accuracy_score(y_pred_train,y_train)}")
  y_pred_test = classifier.predict(X_test)
  print( f"{type(classifier).__name__} Test score = {accuracy_score(y_pred_test,y_test)}")
# dicision tree is best"""

model= DecisionTreeClassifier()
model.fit(S_X,y)

# Save the trained model using joblib
joblib.dump(model, os.path.join(os.getcwd(),'final_model.pkl'))