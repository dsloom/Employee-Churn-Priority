import mysql.connector
import pandas as pd
import pickle
import os

mydb= mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="employees"
)

def get_data_frame():
     #2 . create a cursor
    cursor = mydb.cursor()
    #3 . sql statement
    sql= "select * from employee_details;"
    #4 . Execute the sql statement
    cursor.execute(sql)
    #5 . get the result from the cursor
    cursor.fetchall()
    df=pd.read_sql_query(sql,mydb)
    print(df)
    #save the datafarme as pickle
    with open(os.path.join(os.getcwd(),"employee_df.pkl"),"wb") as employee_df:
        pickle.dump(df,employee_df)
        
get_data_frame()
#