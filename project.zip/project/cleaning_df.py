import pandas as pd
import pickle 
import os


#load the dataframe from the binary file using pickle

with open(os.path.join(os.getcwd(),"employee_df.pkl"),"rb") as employee_df:
    df= pickle.load(employee_df)
#print(df)  
df.drop(["gender","name","id"],axis=1,inplace=True)
print(df.info())
df.duplicated().sum()
print(df.isna())
#save the datafarme as pickle
with open(os.path.join(os.getcwd(),"c_employee_df.pkl"),"wb") as c_employee_df:
    pickle.dump(df,c_employee_df)
