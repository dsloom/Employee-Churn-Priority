# streamlit run deployment.py
import pickle
import os 
from pathlib import Path
import streamlit as st
import joblib
import pandas as pd


os.chdir(Path(__file__).parent)



#define the streamlit app

def main():
    # Load the trained model
    model = joblib.load(os.path.join(os.getcwd(),"final_model.pkl"))

    st.title("Employee churn prediction")
    st.markdown("Enter Employee Data : ")
    age=int(st.text_input("age", 50)) # 50 is a default value
    salary=int(st.text_input("salary", 5000))
    tenure=int(st.text_input("tenure", 5))
    performance_rating=int(st.text_input("performance_rating", 4))
    if st.button("Predict"):
        input_dict = {
            'age': age,
            'salary': salary,
            'tenure': tenure,
            'performance_rating': performance_rating
        }

        prediction_churn =  round(float(model.predict(pd.DataFrame([input_dict]))[0]), 2)
        

        st.success(f"The predicted churn  is : {prediction_churn} ")

if __name__=="__main__":
    main()